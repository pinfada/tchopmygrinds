$(document).ready(function()
{
    L.Icon.Default.imagePath = '/assets/';

});
